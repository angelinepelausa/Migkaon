const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');  // Import bcrypt for password hashing and comparison

const app = express();
const port = 3000;

// Configure Multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

// Connect to SQLite database
const dbPath = path.join(__dirname, 'database', 'recipes.db');
const db = new sqlite3.Database(dbPath);

// Middleware to parse JSON bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Route handler for adding a new recipe
app.post('/addRecipe', upload.single('image'), (req, res) => {
    const { recipeName, ingredients, instructions } = req.body;
    const image = req.file ? req.file.filename : null;

    // Validate inputs
    if (!recipeName || !ingredients || !instructions) {
        return res.status(400).json({ error: 'Please provide all fields: recipeName, ingredients, instructions' });
    }

    // Insert into SQLite database
    const sql = `INSERT INTO recipes (name, ingredients, instructions, image) VALUES (?, ?, ?, ?)`;
    db.run(sql, [recipeName, ingredients, instructions, image], function(err) {
        if (err) {
            console.error('Error adding recipe:', err.message);
            return res.status(500).json({ error: 'Failed to add recipe' });
        }
        console.log(`Recipe added with ID: ${this.lastID}`);
        res.status(200).send('Recipe added successfully');
    });
});

// Route handler for the homepage
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route handler for the login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }

    // Query to find user with the given username
    const sql = `SELECT * FROM profile_information WHERE username = ?`;
    db.get(sql, [username], async (err, row) => {
        if (err) {
            console.error('Error querying the database:', err.message);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (row) {
            // Check the password using bcrypt
            try {
                const match = await bcrypt.compare(password, row.password);
                if (match) {
                    // Password is correct
                    res.status(200).json({ success: true });
                } else {
                    // Password is incorrect
                    res.status(401).json({ error: 'Invalid username or password' });
                }
            } catch (error) {
                console.error('Error comparing passwords:', error.message);
                res.status(500).json({ error: 'Internal server error' });
            }
        } else {
            // No user found with that username
            res.status(401).json({ error: 'Invalid username or password' });
        }
    });
});

// Route handler for the signup page
app.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        // Check if username or email already exists
        const checkSql = `SELECT * FROM profile_information WHERE username = ? OR email = ?`;
        const row = await new Promise((resolve, reject) => {
            db.get(checkSql, [username, email], (err, row) => {
                if (err) {
                    console.error('Error querying the database:', err.message);
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });

        if (row) {
            // Username or email already exists
            return res.status(400).json({ error: 'Username or email already exists' });
        }

        // Hash the password before inserting
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert new user into the database
        const insertSql = `INSERT INTO profile_information (username, email, password) VALUES (?, ?, ?)`;
        await new Promise((resolve, reject) => {
            db.run(insertSql, [username, email, hashedPassword], function (err) {
                if (err) {
                    console.error('Error adding user:', err.message);
                    reject(err);
                } else {
                    console.log(`User added with ID: ${this.lastID}`);
                    resolve();
                }
            });
        });

        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Error hashing password or inserting user:', error.message);
        res.status(500).json({ error: 'Failed to sign up' });
    }
});

// Route handler for the landing page
app.get('/landing.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'landing.html'));
});

// Route to check if email or username is unique
app.post('/check-credentials', async (req, res) => {
    const { email, username } = req.body;

    const sql = `SELECT * FROM profile_information WHERE username = ? OR email = ?`;
    const row = await new Promise((resolve, reject) => {
        db.get(sql, [username, email], (err, row) => {
            if (err) {
                console.error('Error querying the database:', err.message);
                reject(err);
            } else {
                resolve(row);
            }
        });
    });

    res.json({ isUnique: !row });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
