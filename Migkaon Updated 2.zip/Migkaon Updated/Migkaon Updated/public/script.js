// script.js

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('rectangleForm');

    form.addEventListener('submit', async (event) => {
        event.preventDefault(); // Prevent the default form submission

        // Get form values
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Check if username and password are not empty
        if (!username || !password) {
            alert('Please enter both username and password.');
            return;
        }

        try {
            // Send a POST request to the server
            const response = await fetch('/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            // Parse JSON response from the server
            const result = await response.json();

            if (response.ok && result.success) {
                // Show success message and redirect to the landing page
                alert('Logged in successfully');
                window.location.href = '/landing.html';
            } else {
                // Show error message
                alert(result.error || 'Login failed.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while logging in.');
        }
    });
});
