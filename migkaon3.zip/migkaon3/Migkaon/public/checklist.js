document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('ingredientForm');
    const recipeContainer = document.getElementById('recipeContainer');

    form.addEventListener('submit', async (event) => {
        event.preventDefault(); 

        const checkedIngredients = Array.from(form.querySelectorAll('input[type="checkbox"]:checked'))
            .map(checkbox => checkbox.value.toLowerCase());

        try {
            const response = await fetch('/getRecipesByIngredients', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ ingredients: checkedIngredients })
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const recipes = await response.json();

            recipeContainer.innerHTML = '';

            recipes.forEach(recipe => {
                const recipeCard = document.createElement('div');
                recipeCard.className = 'recipe-card';

                const recipeImage = document.createElement('img');
                recipeImage.src = recipe.image ? recipe.image : 'assets/default_recipe_image.png';
                recipeImage.alt = recipe.name;

                const recipeName = document.createElement('div');
                recipeName.className = 'recipe-name';
                recipeName.textContent = recipe.name;

                const recipeIngredients = document.createElement('div');
                recipeIngredients.className = 'recipe-ingredients';
                recipeIngredients.textContent = `Ingredients: ${recipe.ingredients.split(',').join(', ')}`;

                const recipeInstructions = document.createElement('div');
                recipeInstructions.className = 'recipe-instructions';
                recipeInstructions.textContent = `Instructions: ${recipe.instructions}`;

                recipeCard.appendChild(recipeImage);
                recipeCard.appendChild(recipeName);
                recipeCard.appendChild(recipeIngredients);
                recipeCard.appendChild(recipeInstructions);
                recipeContainer.appendChild(recipeCard);
            });

            if (recipes.length === 0) {
                recipeContainer.innerHTML = '<p>No recipes found for the selected ingredients.</p>';
            }

        } catch (error) {
            console.error('Error fetching recipes:', error);
            recipeContainer.innerHTML = '<p>Error fetching recipes. Please try again.</p>';
        }
    });
});
