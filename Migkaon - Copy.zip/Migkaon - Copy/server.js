const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

const dbPath = path.join(__dirname, 'database', 'recipes.db');
const db = new sqlite3.Database(dbPath);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

app.post('/addRecipe', (req, res) => {
    const { recipeName, ingredients, instructions } = req.body;

    if (!recipeName || !ingredients || !instructions) {
        return res.status(400).json({ error: 'Please provide all fields: recipeName, ingredients, instructions' });
    }

    const sql = `INSERT INTO recipes (name, ingredients, instructions) VALUES (?, ?, ?)`;
    db.run(sql, [recipeName, ingredients, instructions], function(err) {
        if (err) {
            console.error('Error adding recipe:', err.message);
            return res.status(500).json({ error: 'Failed to add recipe' });
        }
        console.log(`Recipe added with ID: ${this.lastID}`);
        res.status(200).send('Recipe added successfully');
    });
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
