document.addEventListener('DOMContentLoaded', () => {
    const recipeForm = document.getElementById('recipeForm');

    recipeForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const recipeName = document.getElementById('recipeName').value;
        const ingredients = document.getElementById('ingredients').value;
        const instructions = document.getElementById('instructions').value;

        try {
            const response = await fetch('/addRecipe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ recipeName, ingredients, instructions }),
            });

            if (!response.ok) {
                throw new Error('Failed to add recipe');
            }

            alert('Recipe added successfully!');
            recipeForm.reset(); 
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to add recipe. Please try again.');
        }
    });
});
